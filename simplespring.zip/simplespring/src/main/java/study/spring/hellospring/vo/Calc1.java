package study.spring.hellospring.vo;


/**
 * 맴버변수와 메서드를 갖는 형태
 */
public class Calc1 {
	private int x = 1;
	private int y = 2;
	
	public int sum() {
		return this.x + this.y;
	}
}
