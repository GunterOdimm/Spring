package study.spring.hellospring.service;

public interface SchoolService {
	public String addDate();
	public String getDateItem();
	public String getDateList();
	public String editDate();
	public String deleteDate();
	

}
